package swu.edu.cn.sql.user;

import swu.edu.cn.sql.UserManagement;





public class QiantouLeaderUser extends UserManagement {
	
	
	String	qiantouLeaderName;
	
	public QiantouLeaderUser(){
		
	}
	
	public QiantouLeaderUser(String	qiantouLeaderName){
		this.qiantouLeaderName=qiantouLeaderName;
		
	}
	
	
	
	

}
