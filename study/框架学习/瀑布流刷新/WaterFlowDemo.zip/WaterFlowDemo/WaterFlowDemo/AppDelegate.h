//
//  AppDelegate.h
//  WaterFlowDemo
//
//  Created by Jerry Xu on 7/8/13.
//  Copyright (c) 2013 Jerry Xu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
