//
//  PhotoInfo.m
//  WaterFlowDemo
//
//  Created by Jerry Xu on 7/9/13.
//  Copyright (c) 2013 Jerry Xu. All rights reserved.
//

#import "PhotoInfo.h"

@implementation PhotoInfo

@end
