/*
 * draggable_tickets.js
 */
(function($) {

module("draggable: tickets");

})(jQuery);
