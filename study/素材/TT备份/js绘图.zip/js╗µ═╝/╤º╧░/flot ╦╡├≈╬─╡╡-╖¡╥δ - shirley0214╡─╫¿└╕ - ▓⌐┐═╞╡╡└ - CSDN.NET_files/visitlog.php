i 88a84010c8e4b5480c37433f36a346a4
Query failed : Can't open file: 'visitlog.MYI' (errno: 145)