var phpcms_path = 'http://pub.chinaunix.net/';
var cookie_pre = 'cu_pub_';
var cookie_domain = 'pub.chinaunix.net';
var cookie_path = '/';
