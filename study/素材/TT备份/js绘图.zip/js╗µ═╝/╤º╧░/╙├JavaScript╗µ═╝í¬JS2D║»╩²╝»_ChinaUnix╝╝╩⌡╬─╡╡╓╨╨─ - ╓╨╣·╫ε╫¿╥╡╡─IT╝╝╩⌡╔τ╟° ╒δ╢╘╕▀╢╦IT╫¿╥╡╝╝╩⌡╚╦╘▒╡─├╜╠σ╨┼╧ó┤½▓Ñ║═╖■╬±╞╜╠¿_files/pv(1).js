var d=new Date();
var timestamp=""+d.getFullYear()+d.getMonth()+d.getDate();
document.write(unescape('%3Cscript language="javascript" type="text/javascript" src="http://stat.it168.com/google/pvpv.js?timestamp='+timestamp+'"%3E%3C/script%3E'));