﻿$(document).ready(function () {
    SyntaxHighlighter.autoloader(
              'js jscript javascript  /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushJScript.js',
              'csharp                 /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushCSharp.js',
              'xml xhtml              /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushXml.js',
              'css                    /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushCss.js',
              'php                    /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushPhp.js',
              'plain                  /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushPlain.js',
              'sql                    /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushSql.js',
              'bash                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushBash.js',
              'java                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushJava.js',
              'cpp                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushCpp.js',
              'vb                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushVb.js',
              'perl                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushPerl.js',
              'python                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushPython.js',
              'ruby                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushRuby.js',
              'as3                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushAS3.js',
              'delphi                   /Scripts/syntaxhighlighter_3.0.83/scripts/shBrushDelphi.js'
            );
});