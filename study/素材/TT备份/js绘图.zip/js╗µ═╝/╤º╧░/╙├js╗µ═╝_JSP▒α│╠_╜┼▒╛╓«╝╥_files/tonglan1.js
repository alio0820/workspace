﻿if(getCookie("jb51ad2010")!="noad"){
document.writeln("<div id=\"txtlink\"><ul>");
document.writeln("<li><a href='http://www.cbt9.com' target='_blank'><span  style='color:green;'>藏宝图_hao123网址大全,百度网址大全</span></a></li>");
document.writeln("<li><a title='广告' target='_blank' href='http://sc.jb51.net/'><span  style='color:red;'>脚本之家素材下载中心</span></a></li>");
document.writeln("<li><a href='http://www.xmwzidc.com' target='_blank'><span  style='color:blue;font-weight:bold'>机房直销 海外服务器 海外空间租用 海西数据</span></a></li>");
document.writeln("<li><a href='http://sc.jb51.net' target='_blank'><span  style='color:black;'>脚本之家素材下载中心</span></a></li>");

document.writeln("<li><a href='http://s.jb51.net' target='_blank'><span  style='color:blue;'>服务器常用软件下载</span></a></li>");
document.writeln("<li><a href='http://www.t2.hk' title='' target='_blank'><span  style='color:red;'>T2.HK免备案主机|美国|韩国|香港机房</span></a></li>");
document.writeln("<li><a href='http://www.amazon.cn/b?_encoding=UTF8&node=888465051&tag=reterry&linkCode=ur2&camp=536&creative=3200' title='热门电脑产品一览' target='_blank'><span  style='color:blue;'>热销电脑产品一览 预购从速</span></a></li>");
document.writeln("<li><a href='http://www.t2.hk/' target='_blank'><span  style='color:red;'>T2.HK数据-最专业的海外主机服务器提供商</span></a></li>");
document.writeln("</ul></div><div class=\"blank2\"></div>");
document.write('<div class="topimg"><ul>');
document.write('<li><A href="http://www.zgsj.com/stat/stat.asp?siteKey=jb51&pageNO=1&urlCode=77cef5771225b77870dbe8d4ab71b825" target=_blank><IMG src="http://img.jb51.net/imgby/zgsj_237.gif"></A></li>');
document.write('<li><A href="http://www.idcicp.com/?source=jb51" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/idcicp.gif"></A></li>');
document.write('<li><A href="http://www.pkidc.cn" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/pkidc_237.gif"></A></li>');
document.write('<li><A href="http://www.huangjinlian.cn/" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/hjl_237.gif"></A></li>');
document.write('</ul></div>');
document.write('<div class="blank2"></div>');
document.write('<div class="topimg"><ul>');
document.write('<li><A href="http://www.enkj.com" target=_blank><IMG alt="亿恩科技" src="http://img.jb51.net/imgby/enkj_237.gif"></A></li>');
document.write('<li><A href="http://www.72e.net/?cid=ad_jb51" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/72e_237.gif"></A></li>');
document.write('<li><A href="http://www.jb51.net/article/29333.htm" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/hx2006.gif"></A></li>');
document.write('<li><A href="http://www.comsz.com" target=_blank><IMG alt="互联时空" src="http://img.jb51.net/imgby/comsz.gif"></A></li>');
document.write('</ul></div>');
document.write('<div class="blank2"></div>');
document.write('<div class="topimg"><ul>');
document.write('<li><A href="http://www.longt86.com/" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/hxhmhk.gif"></A></li>');
document.write('<li><A href="http://www.west263.com/?ads=jb51.net" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/west263_237.gif"></A></li>');
document.write('<li><A href="http://www.idc525.com/" target=_blank><IMG alt="" src="http://img.jb51.net/imgby/idc525.gif"></A></li>');
document.write('<li><A href="http://www.zhhzw.com/users/201111.html" target=_blank><IMG alt="中华合租网" src="http://img.jb51.net/imgby/zhhzw_237.gif"></A></li>');
document.write('</ul></div>');
document.writeln("<div class='blank2'></div>");
document.write('<div class="mainlr"><a href="http://www.xunbiz.com/click/click.asp?str=44717c87b8d8fc3a3e18797345b90434" alt="注域名、买空间、建网站、租机器、购邮箱找中国商务网" target="_blank"><img src="http://img.jb51.net/imgby/xunbiz960.gif" width="960" height="60" border="0" /></a></div>');
document.write('<div class="blank2"></div>');
}else{
document.writeln("<div class=\"mainlr\"><a href=\"javascript:yesad2010();location.reload()\"><font color=red>需要购买域名空间的朋友可以点击这里查看idc赞助商列表</font></a><\/div>");	
}
document.writeln("<DIV class=search><UL>");
document.writeln("<LI class=search-hot><SPAN>热门栏目：<\/SPAN>");
document.writeln("<A href=\"http:\/\/www.jb51.net\/list\/list_114_1.htm\" target='_blank'>vbscript<\/A> ");
document.writeln("<A href=\"http:\/\/www.jb51.net\/list\/list_6_1.htm\" target='_blank'>正则表达式<\/A> ");
document.writeln("<A href=\"http:\/\/www.jb51.net\/list\/list_3_1.htm\" target='_blank'>javascript<\/A>");
document.writeln("<A href=\"http:\/\/www.jb51.net\/list\/list_106_1.htm\" target='_blank'>批处理<\/A>");
document.writeln("<A href=\"http:\/\/s.jb51.net\">服务器软件<\/A> ");
document.writeln("<A href=\"http://sc.jb51.net/?txt\" target='_blank' style='color:red'>素材下载<\/A> ");
document.writeln("<\/LI><LI class=search-box>");
document.writeln('<iframe frameborder="0" framespacing="0" height="26" hspace="0" id="baiduframe" marginheight="0" marginwidth="0" scrolling="no" src="http://unstat.baidu.com/bdun.bsc?tn=jb51_pg&cid=1048333&csid=541&bgcr=F0F7FF&urlcr=0000ff&tbsz=300&sropls=2,99&insiteurl=jb51.net&defid=99&kwgp=0&ch=2" style="" vspace="0" width="400"></iframe>');
document.writeln("<\/LI><\/UL></div>");

// 随即广告

