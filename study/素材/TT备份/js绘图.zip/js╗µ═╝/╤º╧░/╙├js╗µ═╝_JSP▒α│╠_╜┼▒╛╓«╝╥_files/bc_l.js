<!--
google_ad_client = "ca-pub-6384567588307613";
google_ad_slot = "7606102353";
google_ad_width = 300;
google_ad_height = 250;
document.write('<scri'+'pt type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></sc'+'ript>');
//-->