﻿google_ad_client = "ca-pub-6384567588307613";
google_ad_slot = "2597813188";
google_ad_width = 468;
google_ad_height = 15;
document.write('<sc'+'ript type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></scr'+'ipt>');