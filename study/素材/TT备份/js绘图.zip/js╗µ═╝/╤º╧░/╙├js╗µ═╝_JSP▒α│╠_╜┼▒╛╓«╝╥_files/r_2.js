﻿<!--
document.write("<a href='http://www.geisnic.com/' target='_blank'><img src='http://img.jb51.net/imgby/gs.gif' width='300' height='60'></a>");
//-->