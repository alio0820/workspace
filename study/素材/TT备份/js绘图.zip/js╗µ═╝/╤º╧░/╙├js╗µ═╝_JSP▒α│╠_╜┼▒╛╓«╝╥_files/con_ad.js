<!--
function switchad(adname,adtpname){
if ($(adname) && $(adtpname)){
$(adname).innerHTML=$(adtpname).innerHTML;
$(adtpname).innerHTML='';
}
} 
try{
switchad("logo_m","logo_m_tp");
switchad("logo_r","logo_r_tp");
switchad("tonglan1","tonglan1_tp");
switchad("con_da1","con_da1_tp");
switchad("con_da8","con_da8_tp");
switchad("baidu300","baidu300_tp");
switchad("mainad2","mainad2-tp");
switchad("con_bo1","con_bo_tp");
switchad("title_ad1","title_ad1_tp");
}catch(e){}

//-->