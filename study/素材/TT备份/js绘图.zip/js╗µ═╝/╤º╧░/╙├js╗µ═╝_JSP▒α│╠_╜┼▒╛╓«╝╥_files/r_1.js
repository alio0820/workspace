﻿<!--
document.write("<a href='http://idc567.com' target='_blank'><img src='http://img.jb51.net/imgby/lichen300.gif' width='300' height='80'></a>");
//-->