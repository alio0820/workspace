﻿var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fb88cfc1ccab788f0903cac38c894caa3' type='text/javascript'%3E%3C/script%3E"));

document.write('<scr'+'ipt src="http://s73.cnzz.com/stat.php?id=1585378&web_id=1585378" language="JavaScript"></sc'+'ript>');