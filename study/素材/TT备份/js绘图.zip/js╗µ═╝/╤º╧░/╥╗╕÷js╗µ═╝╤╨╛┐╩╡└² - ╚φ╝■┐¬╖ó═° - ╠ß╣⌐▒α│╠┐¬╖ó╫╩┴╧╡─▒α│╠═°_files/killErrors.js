<!-- 
function killErrors() { 
return true; 
} 
window.onerror = killErrors; 
// --> 

