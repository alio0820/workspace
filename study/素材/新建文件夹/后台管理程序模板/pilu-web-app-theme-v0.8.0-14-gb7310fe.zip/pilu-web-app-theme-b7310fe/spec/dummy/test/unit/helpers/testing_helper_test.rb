require 'test_helper'

class TestingHelperTest < ActionView::TestCase
end
